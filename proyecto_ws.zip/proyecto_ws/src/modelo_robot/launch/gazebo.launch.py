import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, ExecuteProcess, TimerAction
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare


def generate_launch_description():

    # Launch arguments
    declare_use_sim_time_cmd = DeclareLaunchArgument(
        name='use_sim_time',
        default_value='true',
        description='Use simulation (Gazebo) clock if true'
    )

    # Configuraciones
    use_sim_time = LaunchConfiguration('use_sim_time')
    robot_name_in_model = 'modelo_robot'
    package_name = 'modelo_robot'

    # Rutas de paquetes
    pkg_share = FindPackageShare(package=package_name).find(package_name)
    urdf_file_path = os.path.join(pkg_share, 'urdf', 'robot_tanque.urdf')
    world_file_path = os.path.join(pkg_share, 'worlds', 'world.sdf')  # asegúrate de que exista

    # Leer URDF
    with open(urdf_file_path, 'r') as urdf_file:
        robot_desc = urdf_file.read()

        #rivz2
    rviz2 = Node(
        package='rviz2',
        executable='rviz2',
        name='rviz2',
        output='log',
        parameters=[{'use_sim_time': use_sim_time}],
    )

    # Publicar robot_description
    robot_state_publisher_node = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        parameters=[{'use_sim_time': use_sim_time, 'robot_description': robot_desc}],
        output='screen'
    )

    # joint_state_publisher (opcional si tienes joints)
    joint_state_publisher_node = Node(
        package='joint_state_publisher',
        executable='joint_state_publisher',
        parameters=[{'use_sim_time': use_sim_time}],
        name='joint_state_publisher',
        output='screen'
    )

    # Lanzar Ignition Gazebo con el mundo (iniciando automáticamente)
    gazebo = ExecuteProcess(
        cmd=['ign', 'gazebo', '-v', '4', '-r', world_file_path],
        output='screen'
    )


    # Spawn del robot en Ignition Gazebo
    spawn_entity = Node(
        package='ros_gz_sim',
        executable='create',
        arguments=[
            '-name', robot_name_in_model,
            '-topic', 'robot_description',
            '-z', '0.05'
        ],
        output='screen'
    )

        # Bridge entre ROS 2 y Gazebo para cmd_vel y odom
    diff_drive_bridge = Node(
        package='ros_gz_bridge',
        executable='parameter_bridge',
        arguments=[
            "/clock@rosgraph_msgs/msg/Clock@gz.msgs.Clock",
            "/cmd_vel@geometry_msgs/msg/Twist@gz.msgs.Twist",
            "/odom@nav_msgs/msg/Odometry@gz.msgs.Odometry",
            "/joint_states@sensor_msgs/msg/JointState@gz.msgs.Model",
            "/tf@tf2_msgs/msg/TFMessage@gz.msgs.Pose_V",
            "/scan@sensor_msgs/msg/LaserScan@gz.msgs.LaserScan",
            "/tf_static@tf2_msgs/msg/TFMessage@gz.msgs.Pose_V",
        ],
        output='screen'
    )

    # Espera 3 segundos antes de hacer spawn para dar tiempo a que cargue ign gazebo
    spawn_entity_delayed = TimerAction(
        period=3.0,
        actions=[spawn_entity]
    )

    return LaunchDescription([
        declare_use_sim_time_cmd,
        robot_state_publisher_node,
        rviz2,
        #joint_state_publisher_node,
        gazebo,
        spawn_entity_delayed,
        diff_drive_bridge
    ])